from LineAPI.linepy import LINE, OEPoll
from LineAPI.linepy.asynckick import AsyncKick
from LineAPI.akad.ttypes import TalkException, Message
from tools import LiveJSON, FixJSON
from Naked.toolshed.shell import execute_js
import os
import sys
import json
import time
import random
import traceback
import threading
import subprocess

settings = LiveJSON('settings.json')
FixJSON(settings, {'admin':{},'blacklist':{},'protect':{},'Setprofile':{},'profile':False,'gprofile':False,'texts':'ss'})
token = LiveJSON('token.json')
FixJSON(token, {'self':'#'})

for command in ['clear', 'cls']:
    if os.system(command) == 0:
        break
print("""

\t\tสาสฟลุ๊ค
\t\tสาสแบ้ง

""")
kicker = {}
CHROMEOS = "CHROMEOS\t2.1.5\tLogin\t11.2.5"
try:maxgie = LINE('bklcnw1920@tashjw.com','googlexxx',appName=CHROMEOS)
except:maxgie = LINE(appName=CHROMEOS)
try:
    kicker[1] = LINE('lseqo75036@mailnd7.com','googlexxx',appName=CHROMEOS)
    kicker[2] = LINE('ajyjo77735@qortu.com','googlexxx',appName=CHROMEOS)
    kicker[3] = LINE('qjjmqv4830@psk3n.com','googlexxx',appName=CHROMEOS)
    kicker[4] = LINE('wsoogyd524@qortu.com','googlexxx',appName=CHROMEOS)
    kicker[5] = LINE('zqbdnuv555@qortu.com','googlexxx',appName=CHROMEOS)
except Exception as e:
    print(e)
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
oepoll = OEPoll(maxgie)
myMid = maxgie.profile.mid
k1Mid = kicker[1].profile.mid
k2Mid = kicker[2].profile.mid
k3Mid = kicker[3].profile.mid
k4Mid = kicker[4].profile.mid
k5Mid = kicker[5].profile.mid
botMid = [myMid]
kMid = [myMid,k1Mid,k2Mid,k3Mid,k4Mid,k5Mid]
bots = [kicker[1],kicker[2],kicker[3],kicker[4],kicker[5]]

kicker1 = kicker[1]
kicker2 = kicker[2]
kicker3 = kicker[3]
kicker4 = kicker[4]
kicker5 = kicker[5]
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for i in range(5):
    botMid.append(kicker[i+1].profile.mid)

for ki in kicker:
   allcontacts = kicker[ki].getAllContactIds()
   for mid in botMid:
     if mid not in allcontacts and mid != kicker[ki].profile.mid:
        time.sleep(1)
        print(f"[@] เพิ่มเพื่อน {kicker[1].getContact(mid).displayName}")
        kicker[ki].findAndAddContactsByMid(mid)
   
print("[@] ล็อคอินสำเร็จเรียบร้อย")
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

read = {"readPoint": {},"readMember": {},"ROM": {}}

def NOTIFIED_READ_MESSAGE(op):
    try:
        if read['readPoint'][op.param1]:
            if op.param2 in read['readMember'][op.param1]:
                pass
            else:
                read['readMember'][op.param1][op.param2] = True
                read['ROM'][op.param1] = op.param2
        else:
            pass
    except:
        pass

def command(text, prefix):
    if text.split(" ")[0][:len(prefix)] == prefix:
        _req = text.split(" ")
        _req.pop(0)
        return text.split(" ")[0][len(prefix):], [None] if len(_req) == 0 else _req
    return None, [None]

def toChar(text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    return text

HelpMessage = """➣͜™𝙵𝙻𝚄𝙺𝙴➠𝙸𝙽𝚂𝚃𝙰𝙻𝙻⍣★ 
➠ แก๋ว
➠ ถอย
➠ www. pornhup. com
➠ www. xnxx. com
➠ แอดมิน
➠ เพิ่มแอดมิน
➠ ลบแอดมิน
➠ โอ้ย
➠ เพิ่มบัญชีดำ
➠ ปลดบัญชีดำ
➠ ดูคนติดดำ
➠ ล้างบัญชีดำ
➠ เชคสปีด
➠ เชคบั้ค

𝙱𝚈: ➣͜™𝙵𝙻𝚄𝙺𝙴➠𝙸𝙽𝚂𝚃𝙰𝙻𝙻⍣★ 
<< คำสั่งบอท ป้องกัน >>
➠ ต้องการแทค สั่งว่า แทค
➠ ต้องการ ติดบอทก็ให้ทักมา
http://line.me/ti/p/~welcome-2020

<< ก่อนจะดึง ให้เปิดเชิญก่อน >>
➠ พิมพ์ว่า เปิดเชิญ
➠ ดึงเสร็จ ให้สั่ง ปิดเชิญ
➠ ยกเลิกค้างเชิญ พิมพ์ว่า ลบเชิญ

def execute(op):
    global settings
    global kicker
    try:
        if op.type == 0:
            return
        
        if op.type == 11:
            if settings['protect'][op.param1]['qr'] == True:
                try:
                    if maxgie.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in myMid and op.param2 not in settings['admin'][op.param1] and op.param2 not in kMid:
                            random.choice(bots).reissueGroupTicket(op.param1)
                            group = maxgie.getGroup(op.param1)
                            group.preventedJoinByTicket = True
                            settings["blacklist"][op.param2] = True                            
                            random.choice(bots).kickoutFromGroup(op.param1,[op.param2])                            
                            random.choice(bots).updateGroup(X)
                except:
                     pass
        if op.type == 19:
            if settings['protect'][op.param1]['kick'] == True:
                if op.param2 not in myMid and op.param2 not in settings['admin'][op.param1] and op.param2 not in kMid:
                    settings["blacklist"][op.param2] = True
                    random.choice(bots).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass            
        if op.type == 13:
            if settings['protect'][op.param1]['invite'] == True:
                if op.param2 not in myMid and op.param2 not in settings['admin'][op.param1] and op.param2 not in kMid:
                    try:
                        invitor = op.param2
                        gotinvite = []
                        if "\x1e" in op.param3:
                            gotinvite = op.param3.split("\x1e")
                        else:
                            gotinvite.append(op.param3)                        
                        for u in gotinvite:
                            settings["blacklist"][op.param2] = True
                            kicker.cancelGroupInvitation(op.param1,[op.param3])
                            kicker.kickoutFromGroup(op.param1,[op.param2])                              
                    except:
                        try:
                            kicker2.cancelGroupInvitation(op.param1,[op.param3])
                            kicker2.kickoutFromGroup(op.param1,[op.param2]) 
                        except:
                            try:
                                kicker3.cancelGroupInvitation(op.param1,[op.param3])
                                kicker3.kickoutFromGroup(op.param1,[op.param2])     
                            except:
                                try:
                                    kicker4.cancelGroupInvitation(op.param1,[op.param3])
                                    kicker4.kickoutFromGroup(op.param1,[op.param2])     
                                except:
                                    try:
                                        kicker5.cancelGroupInvitation(op.param1,[op.param3])
                                        kicker5.kickoutFromGroup(op.param1,[op.param2])     
                                    except:
                                        pass
              
        if op.type == 17:
            if op.param2 in settings["blacklist"]:
                random.choice(bots).kickoutFromGroup(op.param1,[op.param2])
                G = maxgie.getGroup(op.param1)	
                G.preventedJoinByTicket = True		
                random.choice(bots).updateGroup(G)
            else:
                pass

        if op.type == 26 or op.type == 25:
            msg = op.message
            to = msg.to
            if msg.text == None:
                return
            cmd = msg.text
            if msg.to not in settings["admin"]:
                settings["admin"][msg.to] = {}
            p, kcmd = command(msg.text.lower(),'sx')
            if msg.to not in settings["admin"]:
                settings["admin"] = {}
            if msg.to not in settings["protect"]:
                settings["protect"][msg.to] = {"invite": False, "qr": False,'kick':False}
            if isinstance(settings["protect"][msg.to], bool):
               del settings["protect"][msg.to]
               return execute(op)
            FixJSON(settings["protect"][msg.to], {"invite": False, "qr": False,'kick':False})
            allowed = True if msg._from in botMid else True if msg._from in settings["admin"][msg.to] else False
            isself = msg._from in botMid and msg._from == maxgie.profile.mid
            if cmd.lower() == 'setting':
               group = maxgie.getGroup(to)
               if not group: return
               bOn = []
               for ki in kicker:
                 if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               ret_ = 'protect qr : on' if settings['protect'][msg.to]['qr'] == True else 'protect qr : off'
               ret_ += '\nprotect invite : on' if settings['protect'][msg.to]['invite'] == True else '\nprotect invite : off'
               ret_ += '\nprotect kick : on' if settings['protect'][msg.to]['kick'] == True else '\nprotect kick : off'
               random.choice(bOn).sendMessage(to, toChar(ret_))
            if cmd.lower() == 'proall on' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               settings['protect'][msg.to]['qr'] = True
               settings['protect'][msg.to]['invite'] = True
               settings['protect'][msg.to]['kick'] = True
               random.choice(bOn).sendMessage(msg.to, 'เปิดระบบกันทั้งหมดเรียบร้อย')
            if cmd.lower() == 'proall off' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               settings['protect'][msg.to]['qr'] = False
               settings['protect'][msg.to]['invite'] = False
               settings['protect'][msg.to]['kick'] = False
               random.choice(bOn).sendMessage(msg.to, 'ปิดระบบกันทั้งหมดเรียบร้อย')
            if cmd.lower() == 'proinv on' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               if settings['protect'][msg.to]['invite'] == True:
                  random.choice(bOn).sendMessage(to, 'เปิดระบบกันดึงอยู่แล้ว')
               else:
                  settings['protect'][msg.to]['invite'] = True
                  random.choice(bOn).sendMessage(to, 'เปิดระบบกันดึงเรียบร้อย')
            if cmd.lower() == 'proinv off' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               if settings['protect'][msg.to]['invite'] == False:
                  random.choice(bOn).sendMessage(msg.to, 'ปิดระบบกันดึงอยู่แล้ว')
               else:
                  settings['protect'][msg.to]['invite'] = False
                  random.choice(bOn).sendMessage(msg.to, 'ปิดระบบกันดึงเรียบร้อย')
            if cmd.lower() == 'prokick on' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               if settings['protect'][msg.to]['kick'] == True:
                  random.choice(bOn).sendMessage(to, 'เปิดระบบกันเตะอยู่แล้ว')
               else:
                  settings['protect'][msg.to]['kick'] = True
                  random.choice(bOn).sendMessage(to, 'เปิดระบบกันเตะเรียบร้อย')
            if cmd.lower() == 'prokick off' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               if settings['protect'][msg.to]['kick'] == False:
                  random.choice(bOn).sendMessage(msg.to, 'ปิดระบบกันเตะอยู่แล้ว')
               else:
                  settings['protect'][msg.to]['kick'] = False
                  random.choice(bOn).sendMessage(msg.to, 'ปิดระบบกันเตะเรียบร้อย')
            if cmd.lower() == 'proqr on' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               if settings['protect'][msg.to]['qr'] == True:
                  random.choice(bOn).sendMessage(msg.to, 'เปิดระบบกันลิ้งอยู่แล้ว')
               else:
                  settings['protect'][msg.to]['qr'] = True
                  random.choice(bOn).sendMessage(msg.to, 'เปิดระบบกันลิ้งเรียบร้อย')
            if cmd.lower() == 'proqr off' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               if settings['protect'][msg.to]['qr'] == False:
                  random.choice(bOn).sendMessage(msg.to, 'ปิดระบบกันลิ้งอยู่แล้ว')
               else:
                  settings['protect'][msg.to]['qr'] = False
                  random.choice(bOn).sendMessage(msg.to, 'ปิดระบบกันลิ้งเรียบร้อย')

            if cmd.lower() == 'เจิม' and isself:
               print ("แปปนึงนะรีบอทก่อน..")
               maxgie.sendMessage(to,toChar('resetbot..'))
               python = sys.executable
               os.execl(python, python, *sys.argv)
            if cmd.lower() == 'help' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               try:
                   random.choice(bOn).sendMessage(group.id, toChar(HelpMessage.format(s=settings['texts'])))
               except:pass
            if cmd.lower() == 'status' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               for ki in bOn:
                  try:
                      ki.inviteIntoGroup(to, [ki.profile.mid])
                      message = toChar("kick & invite: ไม่บัค ✔️")
                  except:
                      message = toChar("kick & invite: บัค ✖️")
                  ki.sendMessage(to, message)
            if kcmd[0] == "admin":
                group = maxgie.getGroup(to)
                if not group: return
                if group.id not in settings["admin"]:
                    settings["admin"][group.id] = {}
                if isinstance(settings["admin"][group.id], bool):
                    del settings["admin"][group.id]
                    return execute(op)
                bOn = []
                for ki in kicker:
                    if kicker[ki].profile.mid in [member.mid for member in group.members]:
                        bOn.append(kicker[ki])
                if not bOn: return
                if len(kcmd) <= 2:
                    if len(kcmd) <= 1:
                        message = o = toChar("admin(s) on this group:")
                        for id in settings["admin"][group.id]:
                            message += f"\n- {settings['admin'][group.id][id]}"
                        return random.choice(bOn).sendMessage(group.id, message if len(message) != len(o) else toChar("no admin on this group"))
                    if kcmd[1] == "clear" and isself:
                        if group.id in settings["admin"]:
                            del settings["admin"][group.id]
                            return random.choice(bOn).sendMessage(to, toChar("clear all admin on this group"))
                if kcmd[1] == "add" and allowed:
                    message = o = toChar("add admin(ꜱ):")
                    kcmd.pop(0)
                    kcmd.pop(0)
                    addName = ' '.join(kcmd)
                    addName = addName if not addName.endswith(' ') else addName[:len(addName)-1]
                    for member in group.members:
                       if (addName.lower() in member.displayName.lower() if len(member.displayName) > len(addName) else  member.displayName.lower() in addName.lower()) == True:
                          if member.mid not in botMid and member.mid not in settings["admin"][group.id]:
                              settings["admin"][group.id][member.mid] = member.displayName
                              if member.mid in settings["blacklist"]:
                                  random.choice(bOn).sendMessage(to, f"ᴅᴇʟ {member.displayName} ɪɴ ʙᴀɴʟɪꜱᴛ")
                              message += f"\n- {member.displayName}"
                    return random.choice(bOn).sendMessage(to, message if len(message) != len(o) else toChar("no new admin added."))
                if kcmd[1] == "del" and allowed:
                    message = o = toChar("del admin(ꜱ):")
                    kcmd.pop(0)
                    kcmd.pop(0)
                    addName = ' '.join(kcmd)
                    addName = addName if not addName.endswith(' ') else addName[:len(addName)-1]
                    for member in group.members:
                        if (addName.lower() in member.displayName.lower() if len(member.displayName) > len(addName) else  member.displayName.lower() in addName.lower()) == True:
                            if member.mid not in botMid and member.mid in settings["admin"][group.id]:
                                del settings["admin"][group.id][member.mid]
                                message += f"\n- {member.displayName}"
                    return random.choice(bOn).sendMessage(to, message if len(message) != len(o) else toChar("no admin deleted."))
            if cmd.lower() == 'bots' and isself:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               for ki in bOn:
                   ki.sendMessage(to, '<>')
            if cmd.lower() == 'เชคสปีด' and allowed:
               group = maxgie.getGroup(to) if msg.toType == 2 else None
               if not group:
                  return
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:
                   return
               for ki in bOn:
                  startTime = time.time()
                  profile = ki.getProfile()
                  endTime = time.time() - startTime
                  ki.sendMessage(to, toChar(f'{endTime} second | {int(endTime*1000)} MS'))
            if cmd.lower() == 'admin clear' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               settings['admin'][msg.to] = {}
               random.choice(bOn).sendMessage(to, toChar('del admin done.'))
            if cmd.lower() == 'ban clear' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               settings['blacklist'] = {}
               random.choice(bOn).sendMessage(to, toChar('del blacklist done.'))
            if cmd.lower() == 'ban list' and allowed:
               group = maxgie.getGroup(to)
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               if not bOn:return
               if settings['blacklist'] == {}:return random.choice(bOn).sendMessage(to,toChar('blacklist none.'))
               md = toChar('list blacklist')
               no = 0+1
               for i in settings['blacklist']:
                  md += f'\n{no}. {kicker[1].getContact(i).displayName}'
                  no += 0
               return random.choice(bOn).sendMessage(to, md)
            if cmd.lower().startswith('ban add') and allowed:
                midslist = []
                if "MENTION" in msg.contentMetadata:
                    midslist = [mention["M"] for mention in eval(msg.contentMetadata["MENTION"])["MENTIONEES"]]
                for mids in midslist:
                   group = maxgie.getGroup(to)
                   bOn = []
                   for ki in kicker:
                      if kicker[ki].profile.mid in [member.mid for member in group.members]:
                          bOn.append(kicker[ki])
                   if not bOn:return
                   settings['blacklist'][mids] = True
                   random.choice(bOn).sendMessage(to, toChar(f'add blacklist():\n- {kicker[1].getContact(mids).displayName}'))
            if cmd.lower().startswith('ban del') and allowed:
                midslist = []
                if "MENTION" in msg.contentMetadata:
                    midslist = [mention["M"] for mention in eval(msg.contentMetadata["MENTION"])["MENTIONEES"]]
                for mids in midslist:
                   group = maxgie.getGroup(to)
                   bOn = []
                   for ki in kicker:
                      if kicker[ki].profile.mid in [member.mid for member in group.members]:
                          bOn.append(kicker[ki])
                   if not bOn:return
                   del settings['blacklist'][mids]
                   random.choice(bOn).sendMessage(to, toChar(f'del blacklist():\n- {kicker[1].getContact(mids).displayName}'))
            if cmd.lower() == 'แปปนะ' and allowed:
               group = maxgie.getGroup(to)
               if not group:
                  return
               def func(group):
                   bOn = []
                   nIn = []
                   iC = False
                   for ki in kicker:
                      if kicker[ki].profile.mid not in [member.mid for member in group.members]:
                          nIn.append(kicker[ki])
                      else:
                          bOn.append(kicker[ki])
                   if nIn == []:
                      return random.choice(bOn).sendMessage(group.id, "พวกผมมากันครบแล้ว (｀・ω・´)")
                   if group.preventedJoinByTicket:
                       group.preventedJoinByTicket = False
                       if bOn == []:
                           maxgie.updateGroup(group)
                       else:
                           random.choice(bOn).updateGroup(group)
                       iC = True
                   ticket = maxgie.reissueGroupTicket(group.id)
                   for k in nIn:
                       k.acceptGroupInvitationByTicket(group.id, ticket)
                   if iC == True:
                       group.preventedJoinByTicket = True
                       random.choice(nIn).updateGroup(group)
               TH = threading.Thread(target=func, args=(group,))
               TH.deamon = True
               TH.start()

            if msg.text.lower().startswith("urlprofile "):
                group = maxgie.getGroup(to) if msg.toType == 2 else None
                if not group:return
                bOn = []
                for ki in kicker:
                   if kicker[ki].profile.mid in [member.mid for member in group.members]:
                       bOn.append(kicker[ki])
                for k in bOn:
                    def changeVideoAndPictureProfile(pict, vids):
                        try:
                           files = {'file': open(vids, 'rb')}
                           obs_params = k.genOBSParams({'oid': k.profile.mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
                           data = {'params': obs_params}
                           r_vp = k.server.postContent('{}/talk/vp/upload.nhn'.format(str(k.server.LINE_OBS_DOMAIN)), data=data, files=files)
                           if r_vp.status_code != 201:
                              return "Failed update profile"
                           k.updateProfilePicture(pict, 'vp')
                           return "Success update profile"
                        except Exception as e:
                           raise Exception("Error change video and picture profile {}".format(str(e)))
                    keyword = msg.text.replace(msg.text.split(" ")[0] + " ", "")
                    pic = "http://dl.profile.line-cdn.net/{}".format(k.profile.pictureStatus)
                    a = subprocess.getoutput('youtube-dl --format mp4 --output tmp.mp4 {}'.format(keyword))
                    pict = k.downloadFileURL(pic)
                    vids = "tmp.mp4"
                    changeVideoAndPictureProfile(pict, vids)
                    k.sendMessage(to, 'ตั้งโปรไฟล์ YouTube คิกเกอร์แล้ว')
                    os.remove("tmp.mp4")
  
            if cmd.lower() == 'point':
               group = maxgie.getGroup(to) if msg.toType == 2 else None
               if not group: return
               bOn = []
               for ki in kicker:
                  if kicker[ki].profile.mid in [member.mid for member in group.members]:
                      bOn.append(kicker[ki])
               groupMemberMids = [i.mid for i in group.members if i.mid in kMid]
               b=  "พิมว่า read เพื่อดูสมาชิกที่อ่านข้อความ (｀・ω・´)"
               if kMid in groupMemberMids:
                  random.choice(bOn).sendMessage(msg.to, b)
               else:
                  random.choice(bOn).sendMessage(msg.to,b)
                  try:
                      del read['readPoint'][msg.to]
                      del read['readMember'][msg.to]
                  except:pass
                  read['readPoint'][msg.to] = True
                  read['readMember'][msg.to] = {}
                  read['ROM'][msg.to] = {}
            
            if cmd.lower() == 'read':
                try:
                   group = maxgie.getGroup(to) if msg.toType == 2 else None
                   if not group: return
                   bOn = []
                   for ki in kicker:
                      if kicker[ki].profile.mid in [member.mid for member in group.members]:
                         bOn.append(kicker[ki])
                   groupMemberMids = [i.mid for i in group.members if i.mid in kMid]
                   if msg.to in read['readPoint']:
                       if read["ROM"][msg.to] == {}:
                           ed = toChar("\nNone")
                           lread = toChar("None")
                       else:
                           ed = ""
                           for i in read["readMember"][msg.to]:
                               ed += "\n- {}".format(kicker[1].getContact(i).displayName)
                           lr = read["ROM"][msg.to]
                           lread = "- {}".format(kicker[1].getContact(lr).displayName)

                       b="รายชื่อสมาชิกที่อ่านทั้งหมด\n\nสมาชิกที่อ่าน" + ed + "\n\nสมาชิกที่อ่านล่าสุด\n"+lread+"\n\nพิมพ์ point เพื่อตั้งจุดอ่านใหม่ (｀・ω・´)"

                       if kMid in groupMemberMids:
                           random.choice(bOn).sendMessage(msg.to, b)
                       else:
                           random.choice(bOn).sendMessage(msg.to,b)
                   else:
                       b="คุณยังไม่ได้ตั้งจุดอ่าน พิมพ์ point เพื่อตั้งจุดอ่าน (｀・ω・´)"
                       if kMid in groupMemberMids:
                           random.choice(bOn).sendMessage(msg.to, b)
                       else:
                           random.choice(bOn).sendMessage(msg.to,b)
                except Exception as e:
                   random.choice(bOn).sendMessage(to, str(e))
            if cmd.lower() == 'profile self' and isself:
                group = maxgie.getGroup(to) if msg.toType == 2 else None
                if not group:
                   return
                bOn = []
                for ki in kicker:
                   if kicker[ki].profile.mid in [member.mid for member in group.members]:
                       bOn.append(kicker[ki])
                for k in bOn:
                   k.updateProfilePicture(k.downloadFileURL("http://dl.profile.line-cdn.net/{}".format(maxgie.getProfile().pictureStatus)))
                k.sendMessage(msg.to, toChar(f'updated profile new.'))
            if cmd.lower() == 'profile add' and isself:
                group = maxgie.getGroup(to) if msg.toType == 2 else None
                if not group:
                   return
                bOn = []
                for ki in kicker:
                   if kicker[ki].profile.mid in [member.mid for member in group.members]:
                       bOn.append(kicker[ki])
                if not bOn:return
                settings['profile'] = True
                random.choice(bOn).sendMessage(to, 'ลงรูปโปร์ไฟล์ที่จะใส่..')
            if cmd.lower() == "ถอย" and allowed:
                group = maxgie.getGroup(to) if msg.toType == 2 else None
                if not group:
                   return
                inG = []
                for ki in kicker:
                   if kicker[ki].profile.mid in [member.mid for member in group.members]:
                       inG.append(kicker[ki])
                for ki in inG:
                   ki.leaveGroup(group.id)  
            if cmd.lower().startswith('kick') and allowed:
                midslist = []
                if "MENTION" in msg.contentMetadata:
                    midslist = [mention["M"] for mention in eval(msg.contentMetadata["MENTION"])["MENTIONEES"]]
                for mids in midslist:
                   random.choice(bots).kickoutFromGroup(to,[mids])
            if cmd.lower().startswith('name') and isself:
                sep = msg.text.split(" ")
                midn = msg.text.replace(sep[0] + " ","")
                group = maxgie.getGroup(to) if msg.toType == 2 else None
                if not group:
                   return
                bOn = []
                for ki in kicker:
                   if kicker[ki].profile.mid in [member.mid for member in group.members]:
                       bOn.append(kicker[ki])
                for k in bOn:
                   proobj = k.getProfile()
                   proobj.displayName = midn
                   k.updateProfile(proobj)
                k.sendMessage(group.id, toChar(f'New name: {midn} updated'))

        if op.type == 26 or op.type == 25:
            msg = op.message
            text = msg.text
            sender = msg._from
            receiver = msg.to
            msg_id = msg.id
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != maxgie.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
            if msg.contentType == 0:
                if text is None:return
                if settings['profile'] == True:
                   bOn = []
                   for ki in kicker:
                     if kicker[ki].profile.mid in [member.mid for member in maxgie.getGroup(to).members]:
                         bOn.append(kicker[ki])
                   for k in bOn:
                      path = k.downloadObjectMsg(msg_id, saveAs='tmp/picture.jpg')
                      k.updateProfilePicture(path)
                   k.sendMessage(to, 'เปลี่ยนรูปโปรไฟล์เรียบร้อย')
                   settings['profile'] = False
                    
        if op.type == 19:
            if myMid in op.param3:
                if op.param2 in kMid:
                    pass
                if op.param2 in myMid:
                    pass
                if op.param2 in settings['admin'][op.param1]:
                    pass
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        kicker1.kickoutFromGroup(op.param1,[op.param2])
                        kicker1.inviteIntoGroup(op.param1,[op.param3])
                        maxgie.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kicker2.kickoutFromGroup(op.param1,[op.param2])
                            kicker2.inviteIntoGroup(op.param1,[op.param3])
                            maxgie.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kicker3.kickoutFromGroup(op.param1,[op.param2])
                                kicker3.inviteIntoGroup(op.param1,[op.param3])
                                maxgie.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kicker4.kickoutFromGroup(op.param1,[op.param2])
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                    maxgie.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kicker5.kickoutFromGroup(op.param1,[op.param2])
                                        kicker5.inviteIntoGroup(op.param1,[op.param3])
                                        maxgie.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kicker6.kickoutFromGroup(op.param1,[op.param2])
                                            kicker6.inviteIntoGroup(op.param1,[op.param3])
                                            maxgie.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kicker7.kickoutFromGroup(op.param1,[op.param2])
                                                kicker7.inviteIntoGroup(op.param1,[op.param3])
                                                maxgie.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kicker8.kickoutFromGroup(op.param1,[op.param2])
                                                    kicker8.inviteIntoGroup(op.param1,[op.param3])
                                                    maxgie.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kicker9.kickoutFromGroup(op.param1,[op.param2])
                                                        kicker9.inviteIntoGroup(op.param1,[op.param3])
                                                        maxgie.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            kicker10.kickoutFromGroup(op.param1,[op.param2])
                                                            kicker10.inviteIntoGroup(op.param1,[op.param3])
                                                            maxgie.acceptGroupInvitation(op.param1)
                                                        except:pass                                                                                                                                                                                                              
                return
            if k1Mid in op.param3:
                if op.param2 in kMid:
                    pass
                if op.param2 in myMid:
                    pass
                if op.param2 in settings['admin'][op.param1]:
                    pass
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        kicker2.kickoutFromGroup(op.param1,[op.param2])
                        kicker2.inviteIntoGroup(op.param1,[op.param3])
                        kicker1.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kicker3.kickoutFromGroup(op.param1,[op.param2])
                            kicker3.inviteIntoGroup(op.param1,[op.param3])
                            kicker1.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kicker4.kickoutFromGroup(op.param1,[op.param2])
                                kicker4.inviteIntoGroup(op.param1,[op.param3])
                                kicker1.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kicker4.kickoutFromGroup(op.param1,[op.param2])
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                    maxgie.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kicker5.kickoutFromGroup(op.param1,[op.param2])
                                        kicker5.inviteIntoGroup(op.param1,[op.param3])
                                        kicker1.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kicker6.kickoutFromGroup(op.param1,[op.param2])
                                            kicker6.inviteIntoGroup(op.param1,[op.param3])
                                            kicker1.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kicker7.kickoutFromGroup(op.param1,[op.param2])
                                                kicker7.inviteIntoGroup(op.param1,[op.param3])
                                                kicker1.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kicker8.kickoutFromGroup(op.param1,[op.param2])
                                                    kicker8.inviteIntoGroup(op.param1,[op.param3])
                                                    kicker1.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kicker9.kickoutFromGroup(op.param1,[op.param2])
                                                        kicker9.inviteIntoGroup(op.param1,[op.param3])
                                                        kicker1.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            kicker10.kickoutFromGroup(op.param1,[op.param2])
                                                            kicker10.inviteIntoGroup(op.param1,[op.param3])
                                                            kicker1.acceptGroupInvitation(op.param1)
                                                        except:pass                                                                                                                                                                                                              
                return
            if k2Mid in op.param3:
                if op.param2 in kMid:
                    pass
                if op.param2 in myMid:
                    pass
                if op.param2 in settings['admin'][op.param1]:
                    pass
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        kicker1.kickoutFromGroup(op.param1,[op.param2])
                        kicker1.inviteIntoGroup(op.param1,[op.param3])
                        kicker2.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kicker3.kickoutFromGroup(op.param1,[op.param2])
                            kicker3.inviteIntoGroup(op.param1,[op.param3])
                            kicker2.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kicker4.kickoutFromGroup(op.param1,[op.param2])
                                kicker4.inviteIntoGroup(op.param1,[op.param3])
                                kicker2.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kicker4.kickoutFromGroup(op.param1,[op.param2])
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                    maxgie.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kicker5.kickoutFromGroup(op.param1,[op.param2])
                                        kicker5.inviteIntoGroup(op.param1,[op.param3])
                                        kicker2.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kicker6.kickoutFromGroup(op.param1,[op.param2])
                                            kicker6.inviteIntoGroup(op.param1,[op.param3])
                                            kicker2.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kicker7.kickoutFromGroup(op.param1,[op.param2])
                                                kicker7.inviteIntoGroup(op.param1,[op.param3])
                                                kicker2.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kicker8.kickoutFromGroup(op.param1,[op.param2])
                                                    kicker8.inviteIntoGroup(op.param1,[op.param3])
                                                    kicker2.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kicker9.kickoutFromGroup(op.param1,[op.param2])
                                                        kicker9.inviteIntoGroup(op.param1,[op.param3])
                                                        kicker2.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            kicker10.kickoutFromGroup(op.param1,[op.param2])
                                                            kicker10.inviteIntoGroup(op.param1,[op.param3])
                                                            kicker2.acceptGroupInvitation(op.param1)
                                                        except:pass                                                                                                                                                                                                              
                return
            if k3Mid in op.param3:
                if op.param2 in kMid:
                    pass
                if op.param2 in myMid:
                    pass
                if op.param2 in settings['admin'][op.param1]:
                    pass
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        kicker2.kickoutFromGroup(op.param1,[op.param2])
                        kicker2.inviteIntoGroup(op.param1,[op.param3])
                        kicker3.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kicker1.kickoutFromGroup(op.param1,[op.param2])
                            kicker1.inviteIntoGroup(op.param1,[op.param3])
                            kicker3.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kicker4.kickoutFromGroup(op.param1,[op.param2])
                                kicker4.inviteIntoGroup(op.param1,[op.param3])
                                kicker3.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kicker4.kickoutFromGroup(op.param1,[op.param2])
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                    maxgie.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kicker5.kickoutFromGroup(op.param1,[op.param2])
                                        kicker5.inviteIntoGroup(op.param1,[op.param3])
                                        kicker3.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kicker6.kickoutFromGroup(op.param1,[op.param2])
                                            kicker6.inviteIntoGroup(op.param1,[op.param3])
                                            kicker3.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kicker7.kickoutFromGroup(op.param1,[op.param2])
                                                kicker7.inviteIntoGroup(op.param1,[op.param3])
                                                kicker3.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kicker8.kickoutFromGroup(op.param1,[op.param2])
                                                    kicker8.inviteIntoGroup(op.param1,[op.param3])
                                                    kicker3.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kicker9.kickoutFromGroup(op.param1,[op.param2])
                                                        kicker9.inviteIntoGroup(op.param1,[op.param3])
                                                        kicker3.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            kicker10.kickoutFromGroup(op.param1,[op.param2])
                                                            kicker10.inviteIntoGroup(op.param1,[op.param3])
                                                            kicker3.acceptGroupInvitation(op.param1)
                                                        except:pass                                                                                                                                                                                                              
                return
            if k4Mid in op.param3:
                if op.param2 in kMid:
                    pass
                if op.param2 in myMid:
                    pass
                if op.param2 in settings['admin'][op.param1]:
                    pass
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        kicker2.kickoutFromGroup(op.param1,[op.param2])
                        kicker2.inviteIntoGroup(op.param1,[op.param3])
                        kicker4.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kicker3.kickoutFromGroup(op.param1,[op.param2])
                            kicker3.inviteIntoGroup(op.param1,[op.param3])
                            kicker4.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kicker1.kickoutFromGroup(op.param1,[op.param2])
                                kicker1.inviteIntoGroup(op.param1,[op.param3])
                                kicker4.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kicker4.kickoutFromGroup(op.param1,[op.param2])
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                    maxgie.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kicker5.kickoutFromGroup(op.param1,[op.param2])
                                        kicker5.inviteIntoGroup(op.param1,[op.param3])
                                        kicker4.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kicker6.kickoutFromGroup(op.param1,[op.param2])
                                            kicker6.inviteIntoGroup(op.param1,[op.param3])
                                            kicker4.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kicker7.kickoutFromGroup(op.param1,[op.param2])
                                                kicker7.inviteIntoGroup(op.param1,[op.param3])
                                                kicker4.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kicker8.kickoutFromGroup(op.param1,[op.param2])
                                                    kicker8.inviteIntoGroup(op.param1,[op.param3])
                                                    kicker4.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kicker9.kickoutFromGroup(op.param1,[op.param2])
                                                        kicker9.inviteIntoGroup(op.param1,[op.param3])
                                                        kicker4.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            kicker10.kickoutFromGroup(op.param1,[op.param2])
                                                            kicker10.inviteIntoGroup(op.param1,[op.param3])
                                                            kicker4.acceptGroupInvitation(op.param1)
                                                        except:pass                                                                                                                                                                                                              
                return
            if k5Mid in op.param3:
                if op.param2 in kMid:
                    pass
                if op.param2 in myMid:
                    pass
                if op.param2 in settings['admin'][op.param1]:
                    pass
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        kicker2.kickoutFromGroup(op.param1,[op.param2])
                        kicker2.inviteIntoGroup(op.param1,[op.param3])
                        kicker5.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kicker3.kickoutFromGroup(op.param1,[op.param2])
                            kicker3.inviteIntoGroup(op.param1,[op.param3])
                            kicker5.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kicker4.kickoutFromGroup(op.param1,[op.param2])
                                kicker4.inviteIntoGroup(op.param1,[op.param3])
                                kicker5.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kicker4.kickoutFromGroup(op.param1,[op.param2])
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                    maxgie.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker1.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker2.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker3.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker4.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker5.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker6.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker7.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker8.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker9.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kicker10.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kicker4.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kicker4.updateGroup(G)
                                    Ticket = kicker4.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kicker1.kickoutFromGroup(op.param1,[op.param2])
                                        kicker1.inviteIntoGroup(op.param1,[op.param3])
                                        kicker5.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kicker6.kickoutFromGroup(op.param1,[op.param2])
                                            kicker6.inviteIntoGroup(op.param1,[op.param3])
                                            kicker5.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kicker7.kickoutFromGroup(op.param1,[op.param2])
                                                kicker7.inviteIntoGroup(op.param1,[op.param3])
                                                kicker5.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kicker8.kickoutFromGroup(op.param1,[op.param2])
                                                    kicker8.inviteIntoGroup(op.param1,[op.param3])
                                                    kicker5.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kicker9.kickoutFromGroup(op.param1,[op.param2])
                                                        kicker9.inviteIntoGroup(op.param1,[op.param3])
                                                        kicker5.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            kicker10.kickoutFromGroup(op.param1,[op.param2])
                                                            kicker10.inviteIntoGroup(op.param1,[op.param3])
                                                            kicker5.acceptGroupInvitation(op.param1)
                                                        except:pass                                                                                                                                                                                                              
                return
                
        if op.type == 55:
            NOTIFIED_READ_MESSAGE(op)
            if op.param2 in settings["blacklist"]:
                if op.param2 not in myMid and op.param2 not in settings['admin'][op.param1] and op.param2 not in kMid:
                    random.choice(bots).kickoutFromGroup(op.param1,[op.param2])
                    G = maxgie.getGroup(op.param1)	
                    G.preventedJoinByTicket = True		
                    random.choice(bots).updateGroup(G)
    except Exception as e:
         print(e)
        
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
while True:
    try:
        ops = oepoll.singleTrace(count=80)
        if ops is not None:
            for op in ops:
                oepoll.setRevision(op.revision)
                thread1 = threading.Thread(target=execute, args=(op,))
                thread1.daemon = True
                thread1.start()
    except Exception as e:
        pass
